import { RootNavigator } from './RootNavigator';

export { RootNavigator };
