import dumbData from './dumbData.json';

import myList from './myList.json';
import previews from './previews.json';
import hostStar from './hostStar.json';

export default {
  dumbData,
  hostStar,
  myList,
  previews,
};
