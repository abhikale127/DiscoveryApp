export const Images = {
  logo: require("../Image/aboutreact.jpg"),
};
