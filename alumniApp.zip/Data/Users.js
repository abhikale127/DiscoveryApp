export const USERS = [
    {
        name:"Ankit Jadhav(2022)",
        profile_img:"https://img.freepik.com/free-icon/nurse_318-201545.jpg?size=338&ext=jpg&ga=GA1.2.1808174785.1665687235&semt=ais",
        upload_img:"hhttps://www.infosectrain.com/wp-content/uploads/2022/06/Job-opportunities-after-Network-certification.jpg",
        messages:"Hey Hello What's App my friend ?",
        unread:2,
        Notification:"Upload new opportunity.",
        time:"1minutes ago",
    },
    {
        name:"Adnan Afrad(2020)",
        profile_img:"https://img.freepik.com/free-icon/user_318-372646.jpg?size=338&ext=jpg&ga=GA1.2.1808174785.1665687235&semt=ais",
        upload_img:"https://scontent.fdac99-1.fna.fbcdn.net/v/t39.30808-6/s206x206/261984169_4543732389040283_1066598624769003766_n.jpg?_nc_cat=105&_nc_rgb565=1&ccb=1-5&_nc_sid=365331&_nc_eui2=AeEJzfAun7uoaGAkzuLJiyvZHKgKbpxOCXgcqApunE4JeDG17kCa7o5nUYiqGNcUb4Mc8LxRfzQgt4uEOMt07O6R&_nc_ohc=7eV2dSMgCXwAX-K5YHb&_nc_ht=scontent.fdac99-1.fna&oh=703e908d2e0822e66a6bab267fcdb030&oe=61AAE64E",
        messages:"What's going on man",
        unread:4,
        Notification:"comment on your photo...",
        time:"11minutes ago",
    },
    {
        name:"Shahriar Nil(2023)",
        profile_img:"https://img.freepik.com/free-icon/man_318-233556.jpg?size=338&ext=jpg&ga=GA1.2.1808174785.1665687235&semt=ais",
        upload_img:"https://scontent.fdac99-1.fna.fbcdn.net/v/t39.30808-6/s280x280/261345551_284412586913029_8566367710671919296_n.jpg?_nc_cat=109&ccb=1-5&_nc_sid=365331&_nc_eui2=AeGVOwdCo81lcMVOu02hT_H8UYhmkH6RfcRRiGaQfpF9xMTG5JjvpcF1zJGmR3aaEkEt4rZdXsvpR8K5QgN6WKwn&_nc_ohc=6xdeJMDJvIcAX9hTUBE&_nc_ht=scontent.fdac99-1.fna&oh=0705da91b3aedfdc91e3d84d2599b25a&oe=61AB9A5D",
        messages:"Hello Brother",
        unread:1,
        Notification:"Upload his Profile Picture",
        time:"12minutes ago",
    },
    {
        name:"Atif Salman(2019)",
        profile_img:"https://img.freepik.com/free-icon/man_318-860806.jpg?size=338&ext=jpg&ga=GA1.1.1808174785.1665687235&semt=ais",
        upload_img:"https://scontent.fdac99-1.fna.fbcdn.net/v/t39.30808-6/s280x280/262036621_421271962990725_6164182286870883744_n.jpg?_nc_cat=109&ccb=1-5&_nc_sid=365331&_nc_eui2=AeGKTmRHSNMCQUbzW04u5YKfCUDId_-FZu4JQMh3_4Vm7gQ5kiPHocm4eEm3rDo84ZtvQNFreV-GAtmMzMnvD1L3&_nc_ohc=nrKlZcFO46wAX8VQ7YH&_nc_ht=scontent.fdac99-1.fna&oh=a4e9402f6a0da16633d983fbe64ed088&oe=61AB34EA",
        messages:"Bondhu",
        unread:1,
        Notification:"react your post",
        time:"15minute ago",
    },
    {
        name:"Shabnam Tinni(2024)",
        profile_img:"https://img.freepik.com/free-icon/man_318-157508.jpg?size=338&ext=jpg&ga=GA1.2.1808174785.1665687235&semt=ais",
        upload_img:"https://scontent.fdac99-1.fna.fbcdn.net/v/t39.30808-6/s280x280/258574898_1016024122305957_141008578972311390_n.jpg?_nc_cat=111&ccb=1-5&_nc_sid=365331&_nc_eui2=AeE3ST4M-A00JN4HOAxgVRbtOtQqp_IHZBA61Cqn8gdkEE6ecRAMtdL_87Ee7-WN2Kf8ocXbVZoxlv9bazJ9VXN3&_nc_ohc=uBW1JBKTl6MAX-C7xQa&_nc_ht=scontent.fdac99-1.fna&oh=86b27feb809ee7756d70b8bb878c53f8&oe=61AE946D",
        messages:"Vondu",
        unread:1,
        Notification:"comment on your photo...",
        time:"1hour ago"
    }
]